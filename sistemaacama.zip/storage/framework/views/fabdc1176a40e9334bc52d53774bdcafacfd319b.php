

<?php $__env->startSection('content'); ?>

  <?php $__env->startSection('page_header'); ?>

  <h6 class="page-title"> 
      <i class="voyager-lab"></i>
      Laboratorio
  </h6>
  <?php $__env->stopSection(); ?>
  
<ul class="nav nav-tabs" id="myTab" role="tablist"> 
    <li class="nav-item" role="menu">
      <a class="nav-link active" id="sucursal-tab" data-toggle="tab" href="#sucursal" role="tab" aria-controls="sucursal" aria-selected="true">Sucursal</a>
    </li>
    <li class="nav-item" role="menu">
      <a class="nav-link" id="simbologia-tab" data-toggle="tab" href="#simbologia" role="tab" aria-controls="simbologia" aria-selected="false">Simbologia</a>
    </li>
    <li class="nav-item" role="menu">
      <a class="nav-link" id="unidad-tab" data-toggle="tab" href="#unidad" role="tab" aria-controls="unidad" aria-selected="false">Unidad</a>
    </li>
  </ul>
  <div class="tab-content" id="myTabContent">
    <div class="tab-pane fade show active" id="sucursal" role="tabpanel" aria-labelledby="sucursal-tab">  
      <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('config.table-sucursal', [])->html();
} elseif ($_instance->childHasBeenRendered('AejUB71')) {
    $componentId = $_instance->getRenderedChildComponentId('AejUB71');
    $componentTag = $_instance->getRenderedChildComponentTagName('AejUB71');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('AejUB71');
} else {
    $response = \Livewire\Livewire::mount('config.table-sucursal', []);
    $html = $response->html();
    $_instance->logRenderedChild('AejUB71', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div> 
    <div class="tab-pane fade" id="simbologia" role="tabpanel" aria-labelledby="simbologia-tab">Simbologia</div>
    <div class="tab-pane fade" id="unidad" role="tabpanel" aria-labelledby="unidad-tab">Unidad</div>
  </div>


<?php $__env->stopSection(); ?>  

<?php echo $__env->make('voyager::master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sistemaacama\resources\views/config/laboratorio.blade.php ENDPATH**/ ?>