<div>
    
    <h1>Hello World!</h1>
</div>
  <?php /**PATH C:\xampp\htdocs\sistemaacama\resources\views/livewire/counter.blade.php ENDPATH**/ ?>