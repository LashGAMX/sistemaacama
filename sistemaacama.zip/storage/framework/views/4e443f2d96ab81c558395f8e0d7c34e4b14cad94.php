<div class="table-responsive">
  <table id="dataTable" class="table table-hover">
      <thead class="thead-dark">
          <tr>
              <th>Id</th>
              <th>Sucursal</th>
              <th>Creación</th>
              <th>Modificación</th>
              <th>Acción</th>
          </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $sucursal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($item->Id_sucursal); ?></td>
              <td><?php echo e($item->Sucursal); ?></td>
              <td><?php echo e($item->created_at); ?></td>
              <td><?php echo e($item->updated_at); ?></td>
              <td>
                  <button class="btn btn-sm btn-info"><i class="voyager-edit"></i> <span hidden-sm hidden-xs>editar</span> </button>
              </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
  </table>
  <script>
    $(document).ready(function() {
    $('#dataTable').DataTable();
    });
  </script>
</div>
 <?php /**PATH C:\xampp\htdocs\sistemaacama\resources\views/livewire/config/table-sucursal.blade.php ENDPATH**/ ?>