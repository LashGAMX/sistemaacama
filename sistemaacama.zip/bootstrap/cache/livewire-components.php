<?php return array (
  'config.table-sucursal' => 'App\\Http\\Livewire\\Config\\TableSucursal',
  'counter' => 'App\\Http\\Livewire\\Counter',
  'user-datatables' => 'App\\Http\\Livewire\\UserDatatables',
);