<?php 
use Illuminate\Support\Facades\Route;

Route::get('intermediarios', function () {
   
});
